
def a_descriptive_name(optional_arguments):
    """A documentation string."""
    # Your function's code goes here. 
    # Your function's code goes here. 
    # Your function's code goes here. 
    return optional_value
